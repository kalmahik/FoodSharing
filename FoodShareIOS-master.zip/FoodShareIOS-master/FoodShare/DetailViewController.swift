//
//  DetailViewController.swift
//  FoodShare
//
//  Created by Егор Петров on 19.11.16.
//  Copyright © 2016 Egor Petrov. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var adres: UILabel!
    @IBOutlet weak var imageOfAd: UIImageView!
    @IBOutlet weak var dataLabel: UILabel!
    @IBOutlet weak var descView: UITextView!
    var indexOfProd: Int!
    var catAd: categoryAdvise?
    override func viewDidLoad() {
        super.viewDidLoad()
        catAd = categoryAdvise()
        dataLabel.text = "Размещено " + (catAd?.dateOfAdvise[indexOfProd])!
        descView.text = catAd?.describe[indexOfProd]
        adres.text = "Забирать по адресу " + (catAd?.adres[indexOfProd])!
        imageOfAd.image = catAd?.imageOfAd[indexOfProd]
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
