//
//  CategoryCell.swift
//  FoodShare
//
//  Created by Егор Петров on 18.11.16.
//  Copyright © 2016 Egor Petrov. All rights reserved.
//

import UIKit

class CategoryCell: UITableViewCell {

    @IBOutlet weak var CategoryImage: UIImageView!
    @IBOutlet weak var CategoryLabel: UILabel!
}
