//
//  TableInitiates.swift
//  FoodShare
//
//  Created by Егор Петров on 18.11.16.
//  Copyright © 2016 Egor Petrov. All rights reserved.
//

import Foundation
import UIKit

class TableInitiates {
    var NameOfImage: [UIImage]
    var NameOfCategory: [String]
    init(){
        NameOfImage = [#imageLiteral(resourceName: "bread"), #imageLiteral(resourceName: "candy"), #imageLiteral(resourceName: "milk"), #imageLiteral(resourceName: "drinks"), #imageLiteral(resourceName: "frozen"), #imageLiteral(resourceName: "fruits"), #imageLiteral(resourceName: "grocery"), #imageLiteral(resourceName: "sauce"), #imageLiteral(resourceName: "something"), #imageLiteral(resourceName: "tea"), #imageLiteral(resourceName: "tins")]
        NameOfCategory = ["Хлеб", "Сладости", "Молочные продукты", "Напитки", "Замороженные продукты", "Фрукты и овощи", "Бакалаея","Соусы", "Прочее...", "Чай и кофе", "Консервы"]
    }
}
