//
//  AdvirtismentCell.swift
//  FoodShare
//
//  Created by Егор Петров on 19.11.16.
//  Copyright © 2016 Egor Petrov. All rights reserved.
//

import UIKit

class AdvertismentCell: UITableViewCell {
    @IBOutlet weak var adviceImage: UIImageView!
    @IBOutlet weak var adviseLabel: UILabel!
    @IBOutlet weak var adviseDate: UILabel!
}
