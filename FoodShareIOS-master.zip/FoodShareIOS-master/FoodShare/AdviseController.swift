//
//  AdviseController.swift
//  FoodShare
//
//  Created by Егор Петров on 19.11.16.
//  Copyright © 2016 Egor Petrov. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
class AdviseController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var formyphp: Int?
    var i = 0
    var catAd: categoryAdvise?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 11
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        i = indexPath.row
    }
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        var deselectedCell = tableView.cellForRow(at: indexPath)!
        deselectedCell.backgroundColor = UIColor.clear
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "DetailSegue"{
            let detailVC = segue.destination as! DetailViewController
            detailVC.indexOfProd = i
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let adviseCell = tableView.dequeueReusableCell(withIdentifier: "AdviseCell", for: indexPath) as! AdvertismentCell
        catAd = categoryAdvise()
        adviseCell.adviseDate.text = catAd?.dateOfAdvise[indexPath.row]
        adviseCell.adviseLabel.text = catAd?.nameOfAd[indexPath.row]
        return adviseCell
   }
}
