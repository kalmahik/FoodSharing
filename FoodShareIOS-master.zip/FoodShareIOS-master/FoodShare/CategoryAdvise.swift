//
//  CategoryAvise.swift
//  FoodShare
//
//  Created by Егор Петров on 19.11.16.
//  Copyright © 2016 Egor Petrov. All rights reserved.
//

import UIKit
class categoryAdvise {
    var imageOfAd: [UIImage]
    var nameOfAd: [String]
    var dateOfAdvise:  [String]
    var adviseId: String?
    var describe: [String]
    var adres: [String]
    
    init(){
        self.imageOfAd = [#imageLiteral(resourceName: "BreadImage"), #imageLiteral(resourceName: "FruitImage"), #imageLiteral(resourceName: "AgushaImage"), #imageLiteral(resourceName: "TinsImage"), #imageLiteral(resourceName: "ParmezanImage"), #imageLiteral(resourceName: "SweetImage"), #imageLiteral(resourceName: "DoshikImage"), #imageLiteral(resourceName: "PelmeniImage"), #imageLiteral(resourceName: "CheeseImage"), #imageLiteral(resourceName: "KetchupImage"), #imageLiteral(resourceName: "CookiesImage")]
        self.nameOfAd = ["Вкусный хлеб", "Свежие фрукты", "Йогурты агуша", "Консервы РусГОСТ", "Пармезан и моцарелло", "Леденцы", "Доширак", "Пельмени", "Сырный соус Heinz", "Кетчуп", "Печеньки"]
        self.dateOfAdvise = ["02.04.2016", "10.11.2016", "10.10.2016", "10.04.2016", "20.10.2016", "10.11.2016", "10.11.2016", "11.08.2016", "10.09.2016", "10.11.2016", "10.07.2016"]
        self.describe = ["Вкусный хлеб приготовленный вчера днем, хранился в подходящих условиях, не черствый. Приезжайте забирайте, будем только рады помочь бедным студентам", "Фрукты сегодня были куплены на рынкке, приехали домой и поняли, что не съедим и половины за неделю, а продукты жалко - испортятся. Приезжайте скорее, збирайте!", "Йогурт Агуша вкусный и полезный для вашего ребенка", "Консервы говяжьи, 15 баночек все новое", "Пармезан и моцарелло привезены из Италии в большом количестве, сами не любители сыра, приезжайте, отдадим задаром", "Леденцы монпасье в железной баночке, не распечатанные", "Дошики - просто вкусная лапша.", "Пельмени домашнего приготовления, просто благотворительность для бедного студента.", "Соус Heinz для мясных блюд, очень вкусный", "Кетчуп, просто кетчуп", "Печеньки" ]
        self.adres = ["Невский, 89", "Ленинский проспект 90", "Колпино, Твераска 44", "Песочная набережная 14", "Ушинская улица 7", "Дмитровское шоссе 7", "Малая садовая 19", "Малая конюшенная 10", "Заневский проспект 10", "Лиговкий проспект 10", "Цветочная улица 10"]
    }
}
